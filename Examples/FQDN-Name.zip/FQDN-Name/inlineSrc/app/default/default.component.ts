import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'default',
  template: `
    <p>
      Congratulations, you have now created a new Windows Admin Center extension!
    </p>
  `,
  styles: [`

  `]
})
export class DefaultComponent implements OnInit {

  constructor() { 
    //
  }

  public ngOnInit() {
    //
  }

}
