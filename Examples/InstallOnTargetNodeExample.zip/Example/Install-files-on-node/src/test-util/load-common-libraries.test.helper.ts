require('./load-jsdom.helper');
require('./load-babel-require.helper');

require('rxjs');

require('@microsoft/windows-admin-center-sdk/core/polyfills');
