import { Component, OnInit } from '@angular/core';
import { AppContextService } from '@microsoft/windows-admin-center-sdk/angular';
import { Observable } from 'rxjs';

@Component({
  selector: 'default-component',
  templateUrl: './default.component.html',
  styleUrls: ['./default.component.css']
})
export class DefaultComponent {
  constructor(private appContextService: AppContextService) {}
  public response: any;
  public installOnNode() {
    this.postToGateway('contoso.install-files-on-node', '1.1.0',
    this.appContextService.activeConnection.value.properties.networkName).subscribe(
      (response: any) => {
        console.log(response);
        this.response = response;
      },
      (error) => {
        console.log(error);
        this.response = error;
      }
    );
  }

  public postToGateway(id: string, version: string, targetNode: string): Observable<any> {
    return this.appContextService.gateway.post(
        `extensions/${id}/versions/${version}/nodes/${targetNode}/install`);
}

}
