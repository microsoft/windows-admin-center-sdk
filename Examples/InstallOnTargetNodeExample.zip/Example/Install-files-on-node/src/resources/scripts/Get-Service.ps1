 Param([string]$name)
 get-service -Name $name