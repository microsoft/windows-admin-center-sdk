import { Component, OnDestroy, OnInit } from '@angular/core';
import { AppContextService, AuthorizationService, NavigationService } from '@microsoft/windows-admin-center-sdk/angular';

@Component({
    selector: 'sme-root',
    template: `
      <!-- Copyright (c) Microsoft Corporation. All rights reserved.
       Licensed under the MIT License. -->

      <sme-ux class="sme-layout-absolute sme-position-inset-none">
        <router-outlet></router-outlet>
      </sme-ux>
    `
})
export class AppComponent implements OnDestroy, OnInit {
    constructor(
        private appContext: AppContextService,  private navigationService: NavigationService) {
    }

    public ngOnInit(): void {
        this.appContext.ngInit({ navigationService: this.navigationService });
    }

    public ngOnDestroy() {
        this.appContext.ngDestroy();
    }
}
