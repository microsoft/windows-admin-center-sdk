/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
import { CommonModule } from '@angular/common';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppContextService, AppErrorHandler, CoreServiceModule, DialogModule, GuidedPanelModule, IconModule, IdleModule, LoadingWheelModule, ResourceService, SmeUxModule } from '@microsoft/windows-admin-center-sdk/angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
export class AppModule {
    /**
     * @param {?} appContextService
     */
    constructor(appContextService) {
        this.appContextService = appContextService;
        this.appContextService.initializeModule({});
    }
}
AppModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    AppComponent
                ],
                imports: [
                    CoreServiceModule,
                    CommonModule,
                    BrowserModule,
                    DialogModule,
                    FormsModule,
                    SmeUxModule,
                    IconModule,
                    LoadingWheelModule,
                    GuidedPanelModule,
                    IdleModule,
                    AppRoutingModule
                ],
                providers: [
                    ResourceService,
                    {
                        provide: ErrorHandler,
                        useClass: AppErrorHandler
                    }
                ],
                bootstrap: [AppComponent]
            },] }
];
/** @nocollapse */
AppModule.ctorParameters = () => [
    { type: AppContextService }
];
if (false) {
    /** @type {?} */
    AppModule.prototype.appContextService;
}
//# sourceMappingURL=app.module.js.map