import { AppContextService } from '@microsoft/windows-admin-center-sdk/angular';
import { Observable } from 'rxjs';
export declare class DefaultComponent {
    private appContextService;
    constructor(appContextService: AppContextService);
    response: any;
    installOnNode(): void;
    postToGateway(id: string, version: string, targetNode: string): Observable<any>;
}
