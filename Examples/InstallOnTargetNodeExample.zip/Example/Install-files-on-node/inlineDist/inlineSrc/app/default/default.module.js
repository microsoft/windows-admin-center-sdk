/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DefaultComponent } from './default.component';
import { Routing } from './default.routing';
export class DefaultModule {
}
DefaultModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    Routing
                ],
                declarations: [DefaultComponent]
            },] }
];
//# sourceMappingURL=default.module.js.map