export declare class DefaultModule {
}
