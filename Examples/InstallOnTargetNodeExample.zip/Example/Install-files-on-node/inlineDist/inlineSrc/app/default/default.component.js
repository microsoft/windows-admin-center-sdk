/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingReturn,uselessCode} checked by tsc
 */
import { Component } from '@angular/core';
import { AppContextService } from '@microsoft/windows-admin-center-sdk/angular';
export class DefaultComponent {
    /**
     * @param {?} appContextService
     */
    constructor(appContextService) {
        this.appContextService = appContextService;
    }
    /**
     * @return {?}
     */
    installOnNode() {
        this.postToGateway('InstallOnNode', '1.0.0', 'sme-full2.redmond.corp.microsoft.com').subscribe((response) => {
            console.log(response);
            this.response = response;
        }, (error) => {
            console.log(error);
            this.response = error;
        });
    }
    /**
     * @param {?} id
     * @param {?} version
     * @param {?} targetNode
     * @return {?}
     */
    postToGateway(id, version, targetNode) {
        return this.appContextService.gateway.post(`extensions/${id}/versions/${version}/nodes/${targetNode}/install`);
    }
}
DefaultComponent.decorators = [
    { type: Component, args: [{
                selector: 'default-component',
                template: `
    <div (click)="installOnNode()">Click to install</div>
    <p *ngIf="response">{{response}}</p>
  `,
                styles: [`

  `]
            }] }
];
/** @nocollapse */
DefaultComponent.ctorParameters = () => [
    { type: AppContextService }
];
if (false) {
    /** @type {?} */
    DefaultComponent.prototype.response;
    /** @type {?} */
    DefaultComponent.prototype.appContextService;
}
//# sourceMappingURL=default.component.js.map