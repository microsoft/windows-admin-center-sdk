import { AppContextService } from '@microsoft/windows-admin-center-sdk/angular';
export declare class AppModule {
    private appContextService;
    constructor(appContextService: AppContextService);
}
