import { BaseUI, Utils } from '@microsoft/windows-admin-center-sdk/e2e';
import { WebElement } from 'selenium-webdriver';

export class EventViewer extends BaseUI {
 
}