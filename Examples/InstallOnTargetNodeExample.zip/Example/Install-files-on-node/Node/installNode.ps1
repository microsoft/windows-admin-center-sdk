﻿$strString = "Hello World"
write-host $strString



$test ="ahahahaha"